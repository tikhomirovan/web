"use strict";

function Sas(name, age, jod) {
    this.name = name;
    this.age = age;
    this.jod = jod;
    this.bas = function(){
        document.write("Я " + this.name + " мне " + this.age + " лет. Я работаю " + this.jod + ".<br>")
    }
}
let dima = new Sas("Дмитрий", 26, "Дзиайнером");
dima.bas();
let stas = new Sas("Сергей", 29, "Программистом");
stas.bas();
let sergei = new Sas("Сергей", 35, "Менеджером");
sergei.bas();