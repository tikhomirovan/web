// let a = +prompt("Введите стоймость покупки: ", "1000");
// if(a < 500){
//     alert("Скидка предостовляется от 500 руб" + "\nИтоговая Стоймость: " + a + " Руб.");
// }
// else if(a >= 500 && a < 1000){
//     alert("Стоймость покупки без скидки: " + a + "\nCкидка: 3%" + "\nИтоговоя стоймость: " + a / 100 * 97 + " Руб.");
// }
// else if(a >= 1000){
//     alert("Стоймость покупки без скидки: " + a + "\nCкидка: 5%" + "\nИтоговоя стоймость: " + a / 100 * 95 + " Руб.");
// }
document.write("<table border = '1' align = 'center' width = '300' height = '300'>");

for (let h = 0; h < 11; h++) {
    document.write("<th align = 'center'>" + h)
}
for (let i = 1; i < 11; i++) {
    document.write("<tr align = 'center'>");
    document.write("<th align = 'center'>")
    document.write(i);
        document.write("</th>");
    for (let j = 1; j < 11; j++) {
        if ((j - i) % 2 == 0) {

            document.write("<td bgcolor='red'>" + i * j + "</td>");
        }
        else {
            document.write("<td bgcolor='green'>" + i * j + "</td>");
        }

    }

    document.write("</tr>");
    document.write("</th>");
}
document.write("</table>");