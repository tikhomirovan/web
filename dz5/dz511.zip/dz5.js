document.write("<div id='van'></div>");
let div = document.getElementById("van");
div.innerHTML = ("Дюбель — конструктивный элемент, который используется для укрепления винта или предмета на стене, на потолке или на полу в помещении или под открытым небом в различных материалах (бетон, кирпич и прочее). Сам дюбель удерживается в конструкции при помощи сил трения. С некоторого времени элементы связи и укрепления, дюбели и винт (шуруп) объединяют в одно целое и используются, прежде всего, для тяжёлых нагрузок. Дюбели предлагаются в различных величинах, которые руководствуются диаметром дюбеля (и соответственно необходимым отверстием), измеренным в миллиметрах..")

div.style.color = "#99ffff";
div.style.background = "#f0f";
div.style.width = "50%";
div.style.outline = "10px dotted #000";
div.className = "resetFont";
let two = document.querySelectorAll(".resetFont")[0];
// console.log(two);
 two.style.fontSize = "12pt";
two.style.fontWeight = "bold";
 two.style.textDecoration = "line-through";