"use strict";

class Div{
    constructor(img,h5){
        
            this.src = img;
            this.h5 = h5;
        
    }
    plus(id){
        let bas = `
        <img src="${this.src}" alt="">
        <h5>${this.h5 = this.h5}</h5>
        `;
        document.querySelector(`#${id}`).innerHTML = bas;
    }
}
let img = "https://cdn0.iconfinder.com/data/icons/human-resource-management-5/64/sq500_exchange_employee_work_company_business-64.png";

let div = new Div(img, "Работа 24 часа в сутки, 7 дней в неделю, 365 дней в году");
div.plus("element")

let img1 = "https://cdn2.iconfinder.com/data/icons/user-interface-line-38/24/Untitled-5-17-64.png"
 
let div1 = new Div(img1, "Нет географических границ");
div1.plus("element1")

let img2 = "https://cdn4.iconfinder.com/data/icons/doodle-3/156/ok-64.png"
let div2 = new Div(img2,"Ассортимент");
div2.plus("element2")

let img3 = "https://cdn1.iconfinder.com/data/icons/seo-9/500/SEO_horn-64.png"
let div3 = new Div(img3,"Безопасность");
div3.plus("element3")

let img4 = "https://cdn1.iconfinder.com/data/icons/crimes-and-justice/100/14-64.png"
let div4 = new Div(img4,"Сокращение расходов на аренду и персоонал");
div4.plus("element4")

let img5 = "https://cdn0.iconfinder.com/data/icons/font-awesome-solid-vol-2/640/handshake-64.png"
let div5 = new Div(img5,"Портнерские отношения");
div5.plus("element5")

let img6 = "https://cdn3.iconfinder.com/data/icons/google-material-design-icons/48/ic_phone_iphone_48px-64.png"
let div6 = new Div(img6,"Покупатель всегда на связи");
div6.plus("element6")

let img7 = "https://cdn0.iconfinder.com/data/icons/untact-economy-1/32/ecommerce_make_a_choice_choose_tick_mark_touchscreen_check-64.png"
let div7 = new Div(img7,"Комфортный выбор");
div7.plus("element7")

let img8 = "https://cdn1.iconfinder.com/data/icons/banking-36/128/transaction_card_payment_cards_credit_1-64.png"
let div8 = new Div(img8,"Удобство оплаты");
div8.plus("element8")


