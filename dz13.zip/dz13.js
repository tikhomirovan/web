let cknop = document.getElementById("cknop");
cknop.addEventListener("click",add)


 function add() {
   let name = document.getElementsByName("text1")[0].value
   let text = document.getElementsByName("text2")[0].value
   
   let regExpBBBold = /<(b|u|i|s|h1|p|a)>(.*)<(\/)\1>/ig;
  text = text.replace(regExpBBBold, "<span style='color:red'>&lt;$1&gt;</span> $2 <span style='color:red'>&lt;$3$1&gt;</span><br>")
  document.write(`
  <fieldset>
  <legend>${name}</legend
  <div>${text}</div>
  </fieldset>
  `)

 }